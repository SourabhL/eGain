# eGain
Node JS API to crawl the data from different websites for Mobile Phones

-   Dev: [https://vpmsywhtkd.execute-api.us-east-1.amazonaws.com/dev/api/mobiles/amazon?product=one%20plus%208](https://vpmsywhtkd.execute-api.us-east-1.amazonaws.com/dev/api/mobiles/amazon?product=one%20plus%208)

## Introduction

This repository contains the React Redux front-end for the InferTrade tool. You can run the tool with partial features on its own, but you need to also deploy the [infertrade-backend](https://github.com/ProjectOPTimize/infertrade-backend/blob/dev/README.md) node server for full functionality.

The main production site is hosted here: https://vpmsywhtkd.execute-api.us-east-1.amazonaws.com/dev/api/mobiles/amazon?product=one%20plus%208 , and has the following main features:

1. Get Product Details by Product Name
2. View Offers from different Websites
3. Get offer from any particular website


## Available Scripts

In the project directory, once you have installed all dependencies with `npm ci` , you can run:

### `npm start`

Runs the app in the development mode.<br>
Open [http://localhost:3001](http://localhost:3001) to view it in the browser.

The page will reload if you make edits.<br>
You will also see any lint errors in the console.

### `npm test`

Launches the test runner in the interactive watch mode.<br>
See the section about [running tests](https://facebook.github.io/create-react-app/docs/running-tests) for more information.

### `npm run test:coverage`

Launches the test runner and generates a coverage report.

### `npm run build`

This command executes `node scripts/build.js` using the packages specified in `package.json`
Builds the app for production to the `build` folder.<br>
It correctly bundles React in production mode and optimizes the build for the best performance.

The build is minified and the filenames include the hashes.<br>
Your app is ready to be deployed!

### `npm run lint`

Runs linting over the build as defined by the `.eslintrc` file

### `npm run lint:watch`

Starts up a process to watch for directory changes and runs the above step when any changes occur.
